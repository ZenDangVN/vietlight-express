<?php $logtra_redux_demo = get_option('redux_demo');?> 

<?php wp_footer(); ?>
</body>
</html>