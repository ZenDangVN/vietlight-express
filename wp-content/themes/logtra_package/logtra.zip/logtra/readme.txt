/*
    Theme Name: Logtra
	Theme URI: http://shtheme.com/demosd/logtra
	Author: Shtheme
	Author URI: https://themeforest.net/user/shtheme
    Release Date: 30 May 2023
    Requirements: WordPress 4.0 or higher, PHP 5
    Compatibility: WordPress 4.9.1
    Tags: web app
    Last Update Date: 30 May 2023
*/

/**** Readme ****/

"Please backup your theme pack files at first before you update the theme into the latest version"

2023.05.30 - version 1.0.0
- First release.